
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author hanwe
 */
public class ScheduleQueries {

    private static Connection connection;
    private static PreparedStatement addSchedule;
    private static PreparedStatement getScheduleList;
    private static ResultSet resultSet; //holds content of query

    //insert a scheduleEntry into query
    public static void addScheduleEntry(ScheduleEntry entry) {
        
        connection = DBConnection.getConnection();
        
        try {
            addSchedule = connection.prepareStatement("insert into app.schedule (semester,studentID,courseCode,Status,timeStamp) values (?,?,?,?,?)");
            addSchedule.setString(1, entry.getSemester());
            addSchedule.setString(2, entry.getStudentID());
            addSchedule.setString(3, entry.getCourseCode());
            addSchedule.setString(4, entry.getStatus());
            addSchedule.setTimestamp(5, entry.getTimeStamp());
            addSchedule.executeUpdate();
         
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }
    
    //get schedule of student identified by semester and studentID
    public static ArrayList<ScheduleEntry> getScheduledStudentsByStudentID(String semester, String studentID) {
        
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedules = new ArrayList<>();
        
        try {
            getScheduleList = connection.prepareStatement("select courseCode, status, timestamp from app.schedule where semester = ? and studentID = ? order by timestamp");
            getScheduleList.setString(1, semester);
            getScheduleList.setString(2, studentID);
            resultSet = getScheduleList.executeQuery();

            while (resultSet.next()) {
                ScheduleEntry schedule = new ScheduleEntry(semester,resultSet.getString(1) ,studentID , resultSet.getString(2), resultSet.getTimestamp(3));
                schedules.add(schedule);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return schedules;

    }
    
//return number of students rolled in a course given the semester and coursecode  
    public static int getScheduleStudentCount(String currentSemester, String courseCode) {
        int count=0;
        connection = DBConnection.getConnection();

        try {
            getScheduleList = connection.prepareStatement("select * from app.schedule where semester = ? and courseCode = ? ");
            getScheduleList.setString(1, currentSemester);
            getScheduleList.setString(2, courseCode);
            resultSet = getScheduleList.executeQuery();
            while (resultSet.next()) {
                count++;
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return count;
    }
}
