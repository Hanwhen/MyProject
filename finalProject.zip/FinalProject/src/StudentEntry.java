/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hanwe
 */
public class StudentEntry {

    private String StudentID;
    private String FirstName;
    private String LastName;

    public StudentEntry(String studentID, String firstName, String lastName) {
        StudentID = studentID;
        FirstName = firstName;
        LastName = lastName;

    }

    public String getStudentID() {
        return StudentID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }
    
    public String toString(){
        return FirstName+" "+LastName+" "+StudentID;
    }

}
