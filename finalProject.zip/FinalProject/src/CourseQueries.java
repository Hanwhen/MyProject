
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author hanwe
 */
public class CourseQueries {

    private static Connection connection;
    private static int seatNumbers;
    private static PreparedStatement addCourse;
    private static PreparedStatement getCourseList;
    private static PreparedStatement getCourseSeats;
    private static ResultSet resultSet; //holds the content from query

    //adding CourseEntry object into data base 
    public static void addCourse(CourseEntry course) {
        
        connection = DBConnection.getConnection();
        
        try {
            addCourse = connection.prepareStatement("insert into app.course (SEMESTER,COURSECODE,DESCRIPTION,SEATS) values (?,?,?,?)");
            addCourse.setString(1, MainFrame.getSemester());
            addCourse.setString(2, course.getCourseCode());
            addCourse.setString(3, course.getCourseDescription());
            addCourse.setInt(4, course.getSeats());
            addCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }

    //get all courses added to a particular semester
    public static ArrayList<CourseEntry> getAllCourse(String semester) {
   
        connection = DBConnection.getConnection();
        ArrayList<CourseEntry> courses = new ArrayList<>();
        
        try {
            getCourseList = connection.prepareStatement("select * from app.course where (semester=?)");
            getCourseList.setString(1, semester); //specify the semester
            resultSet = getCourseList.executeQuery();
            while (resultSet.next()) {
                CourseEntry course = new CourseEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getInt(4));
                courses.add(course);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return courses;

    }

    //get all courses from a semester
    public static ArrayList<String> getAllCourseCode(String semester) {

        connection = DBConnection.getConnection();
        ArrayList<String> courseCodes = new ArrayList<>();

        try {
            getCourseList = connection.prepareStatement("select courseCode from app.course where semester=?");
            getCourseList.setString(1, semester); //specify the semester
            resultSet = getCourseList.executeQuery();

            while (resultSet.next()) 
            {
                String courseCode = resultSet.getString(1);
                courseCodes.add(courseCode);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
       
        return courseCodes;

    }

   //get number of students enrolled in a particulat class by giving semester and coursecode
    public static int getNumStudentsEnrolled(String semester, String courseCode) {
        
        connection = DBConnection.getConnection();
        int registeredStudentCount = 0;
        
        try {
            getCourseSeats = connection.prepareStatement("select count(studentID) from app.schedule where semester = ? and courseCode = ?");
            getCourseSeats.setString(1, semester);
            getCourseSeats.setString(2, courseCode);
            getCourseSeats.executeUpdate();
            resultSet = getCourseSeats.executeQuery();
            registeredStudentCount = resultSet.getInt(1);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return registeredStudentCount;
    }
}
